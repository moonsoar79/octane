"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return (
    <main className="min-h-screen geometric-background p-6 md:p-12 lg:p-24">
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-24"
        >
          <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
            <div className="flex-1">
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 gradient-text">
                Octane Group
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-2xl">
                21 members, no more, no less.
                group of cyber criminals/experts making software thats more.
                <span className="vibrant-text font-bold">  v i b r a n t</span>
              </p>
            </div>
            <div className="relative w-full md:w-96 h-64 md:h-80 rounded-2xl overflow-hidden border border-white/10">
              <Image
                src="https://i.imgur.com/KJXGFOq.png" // Replace with your Imgur link
                alt="Profile Image"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                priority
              />
            </div>
          </div>
        </motion.div>

        {/* Projects Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-24"
        >
          <h2 className="text-2xl font-semibold mb-8 gradient-text"> Projects Of The Month</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project, index) => (
              <Link 
                href={project.link} 
                key={index}
                className="group block p-6 rounded-lg border border-white/10 hover:border-blue-400/50 transition-colors bg-black/30 backdrop-blur-sm"
              >
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-xl font-medium gradient-text">{project.title}</h3>
                  <ArrowUpRight className="opacity-0 group-hover:opacity-100 transition-opacity text-blue-400" />
                </div>
                <p className="text-white/70 mb-4">{project.description}</p>
                {project.image && (
                  <div className="relative w-full h-48 rounded-lg overflow-hidden">
                    <Image
                      src={project.image}
                      alt={project.title}
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                  </div>
                )}
              </Link>
            ))}
          </div>
        </motion.section>

        {/* About Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mb-24"
        >
          <h2 className="text-2xl font-semibold mb-8 gradient-text">About</h2>
          <div className="max-w-2xl">
            <p className="text-lg text-white/70">
              With over 5 years of experience in web development, I specialize in 
              creating responsive and performant web applications. I'm passionate about 
              clean code, accessibility, and creating delightful user experiences.
            </p>
          </div>
        </motion.section>

        {/* Contact Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <h2 className="text-2xl font-semibold mb-8 gradient-text">Contact</h2>
          <Link 
            href="mailto:your.email@example.com"
            className="text-white/70 hover:text-blue-400 transition-colors"
          >
            your.email@example.com
          </Link>
        </motion.section>
      </div>
    </main>
  );
}

const projects = [
  {
    title: "Octane Cheat Engine ",
    description: "Developed By vn (dtr69/pure.gen) THIS PROJECT ",
    link: "#",
    image: "https://i.imgur.com/iNCul3G.png" // Replace with your Imgur link
  },
  {
    title: "Project Two",
    description: "Real-time chat application with end-to-end encryption.",
    link: "#",
    image: "https://i.imgur.com/your-image-2.jpg" // Replace with your Imgur link
  },
  {
    title: "Project Three",
    description: "AI-powered content management system for digital publishers.",
    link: "#",
    image: "https://i.imgur.com/your-image-3.jpg" // Replace with your Imgur link
  },
  {
    title: "Project Four",
    description: "Cross-platform mobile app for fitness tracking.",
    link: "#",
    image: "https://i.imgur.com/your-image-4.jpg" // Replace with your Imgur link
  }
];